extends Node

const EPSILON = 0.001
const PLAYER_COLLISION_LAYER = 2

const COLOR_BG_FB = Color("#CCD5D9EA")

const MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
]
const MONTHS_SHORT = [
	"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"
]

const CHOICE_KEYS = ["choice_1", "choice_2", "choice_3", "choice_4"]

const SETTINGS_CONFIG_PATH = "user://settings.res"
const INPUT_CONFIG_PATH = "user://input.res"
const SAVEGAME_PATH = "user://savegame.res"
const BASE_STORY_DIR_PATH = "res://assets/story"

const MALE = 0
const FEMALE = 1

const UNIVERSAL_FOCUS = "main"

const DEFAULT_LOCALE = "en"
const LOCALES = {
	"en": "Português"
}

##note: set default keybinds in ProjectSettings##
const REMAPPABLE_ACTIONS = [
	{"action": "move_up", "name": "SETTINGS_CTRL_UP", "group": ""},
	{"action": "move_left", "name": "SETTINGS_CTRL_LEFT", "group": ""},
	{"action": "move_down", "name": "SETTINGS_CTRL_DOWN", "group": ""},
	{"action": "move_right", "name": "SETTINGS_CTRL_RIGHT", "group": ""},
	{"action": "interact", "name": "SETTINGS_CTRL_INTERACT", "group": ""},
	{"action": "rhythm_up", "name": "Rhythm up", "group": "Rhythm"},
	{"action": "rhythm_down", "name": "Rhythm down", "group": "Rhythm"},
	{"action": "rhythm_left", "name": "Rhythm left", "group": "Rhythm"},
	{"action": "rhythm_right", "name": "Rhythm right", "group": "Rhythm"},
]

@onready var REGEX_STORE_PATH := RegEx.create_from_string("(\\w+)\\:\\/\\/(.+)")
@onready var REGEX_COMMAND := RegEx.create_from_string("\\$\\s+([a-zA-Z0-9._-]+)\\s*(.*)\\s*")
@onready var REGEX_SUBSTORY_TAG := RegEx.create_from_string("([a-zA-Z0-9_]+)\\s*:\\s*(.+)")
@onready var REGEX_DIALOGUE := RegEx.create_from_string("(?'char_key'[a-zA-Z0-9:_-]+)\\s*(?:\\((?'duration'.+)\\))?\\:\\s*(?'text'.+)")
@onready var REGEX_CHAT := RegEx.create_from_string("(\\w+)\\s*\\:\\s*(.+)")

@onready var CMD_RETURN_NONE := RefCounted.new()

var BUS_IDX_MASTER = AudioServer.get_bus_index("Master")
var BUS_IDX_MUSIC = AudioServer.get_bus_index("Music")
var BUS_IDX_SFX = AudioServer.get_bus_index("SFX")


func _enter_tree():
	print("Until Then Demo %s" % ProjectSettings.get("application/config/version"))
	print("-------------------")
